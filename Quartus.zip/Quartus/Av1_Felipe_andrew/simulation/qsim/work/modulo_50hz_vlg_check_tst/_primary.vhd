library verilog;
use verilog.vl_types.all;
entity modulo_50hz_vlg_check_tst is
    port(
        pulso_1s        : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end modulo_50hz_vlg_check_tst;
