library verilog;
use verilog.vl_types.all;
entity modulo_50hz_vlg_vec_tst is
end modulo_50hz_vlg_vec_tst;
