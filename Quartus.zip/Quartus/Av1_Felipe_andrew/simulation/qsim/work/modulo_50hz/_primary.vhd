library verilog;
use verilog.vl_types.all;
entity modulo_50hz is
    port(
        clk_50mhz       : in     vl_logic;
        rst_n           : in     vl_logic;
        pulso_1s        : out    vl_logic
    );
end modulo_50hz;
