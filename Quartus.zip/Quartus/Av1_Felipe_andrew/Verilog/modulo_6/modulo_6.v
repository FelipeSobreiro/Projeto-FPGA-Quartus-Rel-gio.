module modulo_6 (
    input  wire clk,       // clock de entrada
    input  wire rst_n,     // reset assíncrono, ativo baixo
    input  wire enable,    // habilita a contagem
    output reg [2:0] q,    // saída do contador (0 a 5)
    output wire tc         // terminal count: pulsa quando está em 5 e vai contar
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            q <= 3'd0;
        end else if (enable) begin
            if (q == 3'd5)
                q <= 3'd0;      // volta a zero após 5
            else
                q <= q + 3'd1;  // incrementa normalmente
        end
        // se enable = 0, mantém o valor atual
    end

    assign tc = (q == 3'd5) && enable;  // sinal de carry para o próximo estágio

endmodule