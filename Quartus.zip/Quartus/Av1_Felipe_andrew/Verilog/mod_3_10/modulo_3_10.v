// Copyright (C) 2020  Intel Corporation. All rights reserved.
// Your use of Intel Corporation's design tools, logic functions 
// and other software and tools, and any partner logic 
// functions, and any output files from any of the foregoing 
// (including device programming or simulation files), and any 
// associated documentation or information are expressly subject 
// to the terms and conditions of the Intel Program License 
// Subscription Agreement, the Intel Quartus Prime License Agreement,
// the Intel FPGA IP License Agreement, or other applicable license
// agreement, including, without limitation, that your use is for
// the sole purpose of programming logic devices manufactured by
// Intel and sold by Intel or its authorized distributors.  Please
// refer to the applicable agreement for further details, at
// https://fpgasoftware.intel.com/eula.

// PROGRAM		"Quartus Prime"
// VERSION		"Version 20.1.1 Build 720 11/11/2020 SJ Lite Edition"
// CREATED		"Tue Sep 29 19:51:42 2026"

module modulo_3_10(
	CLK,
	RESET,
	Enable,
	tc,
	Qsaida3,
	Qsaida2,
	Qsaida1,
	Qsaida0,
	Qsaida11,
	Qsaida10
);


input wire	CLK;
input wire	RESET;
input wire	Enable;
output wire	tc;
output wire	Qsaida3;
output wire	Qsaida2;
output wire	Qsaida1;
output wire	Qsaida0;
output wire	Qsaida11;
output wire	Qsaida10;

wire	SYNTHESIZED_WIRE_0;





modulo_10	b2v_inst(
	.clk(CLK),
	.rst_n(RESET),
	.enable(Enable),
	.tc(SYNTHESIZED_WIRE_0)
	);


modulo_3	b2v_inst2(
	.clk(CLK),
	.rst_n(RESET),
	.enable(SYNTHESIZED_WIRE_0),
	.tc(tc)
	);


endmodule
