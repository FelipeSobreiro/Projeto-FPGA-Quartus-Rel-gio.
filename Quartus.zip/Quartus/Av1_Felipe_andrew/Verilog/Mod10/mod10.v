module modulo_10 (
    input  wire clk,       // clock de entrada
    input  wire rst_n,     // reset assíncrono, ativo baixo
    input  wire enable,    // habilita a contagem
    output reg [3:0] q,    // saída do contador (0 a 9)
    output wire tc         // terminal count: pulsa quando está em 9 e vai contar
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            q <= 4'd0;
        end else if (enable) begin
            if (q == 4'd9)
                q <= 4'd0;      // volta a zero após 9
            else
                q <= q + 4'd1;  // incrementa normalmente
        end
        // se enable = 0, mantém o valor atual (não faz nada)
    end

    assign tc = (q == 4'd9) && enable;

endmodule