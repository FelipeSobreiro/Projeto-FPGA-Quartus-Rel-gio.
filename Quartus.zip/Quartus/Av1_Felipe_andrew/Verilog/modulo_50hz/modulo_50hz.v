module modulo_50hz (
    input  wire clk_50mhz,   // clock de entrada, 50 MHz
    input  wire rst_n,       // reset assíncrono, ativo baixo
    output reg  pulso_1s     // pulso de 1 ciclo de clock a cada 1 segundo
);

    // 50 MHz => 50.000.000 ciclos = 1 segundo
    localparam integer CONTAGEM_MAX = 50_000_000 - 1;

    reg [25:0] contador; // 26 bits cobrem até ~67 milhões

    always @(posedge clk_50mhz or negedge rst_n) begin
        if (!rst_n) begin
            contador  <= 26'd0;
            pulso_1s  <= 1'b0;
        end else begin
            if (contador == CONTAGEM_MAX) begin
                contador <= 26'd0;
                pulso_1s <= 1'b1;   // pulso de 1 ciclo
            end else begin
                contador <= contador + 1'b1;
                pulso_1s <= 1'b0;
            end
        end
    end

	 endmodule