module modulo_3 (
    input  wire clk,       // clock de entrada
    input  wire rst_n,     // reset assíncrono, ativo baixo
    input  wire enable,    // habilita a contagem
    output reg [1:0] q,    // saída do contador (0 a 2)
    output wire tc         // terminal count: pulsa quando está em 2 e vai contar
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            q <= 2'd0;
        end else if (enable) begin
            if (q == 2'd2)
                q <= 2'd0;      // volta a zero após 2
            else
                q <= q + 2'd1;  // incrementa normalmente
        end
        // se enable = 0, mantém o valor atual
    end

    assign tc = (q == 2'd2) && enable;  // sinal de carry para o próximo estágio

endmodule